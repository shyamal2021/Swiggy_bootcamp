# Releasing

This repository does not have releases, since HEAD is always the correct commit
to use. Similarly, we rely on semver pseudo-versions in dependor go.mods.
